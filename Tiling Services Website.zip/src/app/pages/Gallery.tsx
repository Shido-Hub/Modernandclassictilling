import { useState } from "react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import imgW1 from "../../imports/w1.jpeg";
import imgW3 from "../../imports/w3.jpeg";
import imgW4 from "../../imports/w4.jpeg";
import imgQ1 from "../../imports/q1.jpeg";
import imgQ4 from "../../imports/q4.jpeg";
import imgA5 from "../../imports/a5.jpeg";
import imgA1 from "../../imports/a1.jpeg";
import imgA2 from "../../imports/a2.jpeg";

export function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = [
    { id: "all", label: "All Projects" },
    { id: "bathroom", label: "Bathrooms" },
    { id: "kitchen", label: "Kitchens" },
    { id: "floor", label: "Floors" },
  ];

  const projects = [
    {
      id: 1,
      category: "bathroom",
      image: imgW1,
      title: "Modern Bathroom",
      description: "Luxury tile installation with custom patterns",
    },
    {
      id: 2,
      category: "kitchen",
      image: imgW3,
      title: "Kitchen Backsplash",
      description: "Contemporary subway tile design",
    },
    {
      id: 3,
      category: "floor",
      image: imgW4,
      title: "Living Room Floor",
      description: "Large format porcelain tiles",
    },
    {
      id: 4,
      category: "bathroom",
      image: imgQ1,
      title: "Shower Installation",
      description: "Waterproof tile with custom niche",
    },
    {
      id: 5,
      category: "bathroom",
      image: imgA2,
      title: "Marble Shower",
      description: "Full marble tile installation with recessed niches",
    },
    {
      id: 6,
      category: "bathroom",
      image: imgA1,
      title: "Showroom Fit-Out",
      description: "Before & after complete transformation",
    },
  ];

  const filteredProjects =
    selectedCategory === "all"
      ? projects
      : projects.filter((project) => project.category === selectedCategory);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-gray-800 to-gray-900 text-white py-20 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">Our Gallery</h1>
          <p className="text-xl max-w-3xl mx-auto text-gray-300">
            Explore our portfolio of completed projects and see the quality of our
            workmanship
          </p>
        </div>
      </section>

      {/* Filter Tabs */}
      <section className="py-12 bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-2 rounded-full transition-colors ${
                  selectedCategory === category.id
                    ? "bg-orange-500 text-white"
                    : "bg-gray-900 text-gray-300 hover:bg-gray-700 border border-gray-700"
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-12 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow"
              >
                <ImageWithFallback
                  src={project.image}
                  alt={project.title}
                  className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-6 text-white">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-gray-200">{project.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-800 py-16 border-t border-gray-700">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Start Your Project?
          </h2>
          <p className="text-xl text-gray-400 mb-8">
            Let us transform your space with professional tiling
          </p>
          <a
            href="/contact"
            className="inline-block bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg transition-colors"
          >
            Get a Free Quote
          </a>
        </div>
      </section>
    </div>
  );
}