import { Link } from "react-router";
import { CheckCircle, Award, Clock, Users } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import imgW1 from "../../imports/w1.jpeg";
import imgW3 from "../../imports/w3.jpeg";
import imgW4 from "../../imports/w4.jpeg";
import imgQ1 from "../../imports/q1.jpeg";
import imgQ2 from "../../imports/q2.jpeg";
import imgQ3 from "../../imports/q3.jpeg";
import imgQ4 from "../../imports/q4.jpeg";
import imgA3 from "../../imports/a3.jpeg";
import imgA4 from "../../imports/a4.jpeg";
import imgA5 from "../../imports/a5.jpeg";
import imgA1 from "../../imports/a1.jpeg";
import imgA2 from "../../imports/a2.jpeg";

export function Home() {
  const features = [
    {
      icon: <Award className="w-12 h-12 text-orange-500" />,
      title: "Expert Craftsmanship",
      description: "Over 15 years of experience in professional tile installation",
    },
    {
      icon: <CheckCircle className="w-12 h-12 text-orange-500" />,
      title: "Quality Materials",
      description: "We use only the highest quality tiles and installation materials",
    },
    {
      icon: <Clock className="w-12 h-12 text-orange-500" />,
      title: "On-Time Delivery",
      description: "Projects completed on schedule with minimal disruption",
    },
    {
      icon: <Users className="w-12 h-12 text-orange-500" />,
      title: "Customer Focused",
      description: "Dedicated to exceeding your expectations on every project",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[700px] flex items-center justify-center overflow-hidden">
        <ImageWithFallback
          src={imgA2}
          alt="Professional tile installation"
          className="absolute inset-0 w-full h-full object-cover scale-105"
        />
        {/* Layered gradient overlay for depth */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/30"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>

        <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
          <div className="max-w-2xl">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-orange-500/20 border border-orange-500/40 text-orange-400 text-sm font-medium px-4 py-2 rounded-full mb-6 backdrop-blur-sm">
              <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
              Professional Tiling Specialists
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight mb-6">
              Modern &amp;<br />
              <span className="text-orange-500">Classic</span> Tiling
            </h1>

            <p className="text-lg md:text-xl text-gray-300 mb-10 leading-relaxed">
              Transforming homes and businesses across Ireland with expert tile installation. Quality craftsmanship, exceptional results.
            </p>

            <div className="flex gap-4 flex-wrap">
              <Link
                to="/contact"
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold transition-colors shadow-lg shadow-orange-500/25"
              >
                Get a Free Quote
              </Link>
              <Link
                to="/gallery"
                className="bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/20 text-white px-8 py-4 rounded-lg font-semibold transition-colors"
              >
                View Our Work
              </Link>
            </div>

            {/* Stats row */}
            <div className="flex gap-8 mt-12 pt-8 border-t border-white/10">
              <div>
                <p className="text-3xl font-bold text-white">15+</p>
                <p className="text-sm text-gray-400 mt-1">Years Experience</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-white">500+</p>
                <p className="text-sm text-gray-400 mt-1">Projects Completed</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-white">100%</p>
                <p className="text-sm text-gray-400 mt-1">Satisfaction Rate</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Why Choose Us?
            </h2>
            <p className="text-xl text-gray-400">
              Professional tiling services you can trust
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-gray-900 p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-700"
              >
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-3 text-white">
                  {feature.title}
                </h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Our Services
            </h2>
            <p className="text-xl text-gray-400">
              Comprehensive tiling solutions for every need
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative h-80 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgW3}
                alt="Bathroom Tiling"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Bathroom Tiling</h3>
                  <p className="text-gray-200">
                    Transform your bathroom with beautiful, waterproof tiles
                  </p>
                </div>
              </div>
            </div>

            <div className="relative h-80 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgW4}
                alt="Kitchen Backsplash"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Kitchen Backsplash</h3>
                  <p className="text-gray-200">
                    Stylish and functional backsplash installations
                  </p>
                </div>
              </div>
            </div>

            <div className="relative h-80 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgQ1}
                alt="Floor Tiling"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Floor Tiling</h3>
                  <p className="text-gray-200">
                    Durable and elegant flooring solutions
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Link
              to="/services"
              className="inline-block bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg transition-colors"
            >
              View All Services
            </Link>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Our Recent Work
            </h2>
            <p className="text-xl text-gray-400">
              Explore our portfolio of completed tiling projects
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Row 1 */}
            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgA2}
                alt="Marble shower installation"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Marble Shower</h3>
                  <p className="text-gray-200 text-sm">Full marble tile installation</p>
                </div>
              </div>
            </div>

            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgA1}
                alt="Showroom before and after"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Showroom Fit-Out</h3>
                  <p className="text-gray-200 text-sm">Complete transformation</p>
                </div>
              </div>
            </div>

            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgQ4}
                alt="Project 3"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Living Room Floor</h3>
                  <p className="text-gray-200 text-sm">Large format porcelain tiles</p>
                </div>
              </div>
            </div>

            {/* Row 2 */}
            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgA3}
                alt="Project 4"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Marble Elegance</h3>
                  <p className="text-gray-200 text-sm">Premium marble tile bathroom</p>
                </div>
              </div>
            </div>

            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgA4}
                alt="Project 5"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Classic Shower</h3>
                  <p className="text-gray-200 text-sm">Timeless tile installation</p>
                </div>
              </div>
            </div>

            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgA5}
                alt="Project 6"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Mosaic Artistry</h3>
                  <p className="text-gray-200 text-sm">Intricate mosaic tile floor</p>
                </div>
              </div>
            </div>

            {/* Row 3 */}
            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgW1}
                alt="Project 7"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Hexagon Pattern</h3>
                  <p className="text-gray-200 text-sm">Geometric tile design</p>
                </div>
              </div>
            </div>

            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgW3}
                alt="Project 8"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Stone Feature Wall</h3>
                  <p className="text-gray-200 text-sm">Natural stone tile accent</p>
                </div>
              </div>
            </div>

            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgW4}
                alt="Project 9"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Modern Kitchen</h3>
                  <p className="text-gray-200 text-sm">Sleek porcelain tile design</p>
                </div>
              </div>
            </div>

            {/* Row 4 */}
            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgQ1}
                alt="Project 10"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Bathroom Renovation</h3>
                  <p className="text-gray-200 text-sm">Complete bathroom tiling project</p>
                </div>
              </div>
            </div>

            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgQ2}
                alt="Project 11"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Decorative Pattern</h3>
                  <p className="text-gray-200 text-sm">Artistic ceramic tile layout</p>
                </div>
              </div>
            </div>

            <div className="relative h-72 rounded-lg overflow-hidden group">
              <ImageWithFallback
                src={imgQ3}
                alt="Project 12"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold mb-1">Expert Installation</h3>
                  <p className="text-gray-200 text-sm">Professional tile work</p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Link
              to="/gallery"
              className="inline-block bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg transition-colors"
            >
              View Full Gallery
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-800 py-16 border-t border-gray-700">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Start Your Project?
          </h2>
          <p className="text-xl text-gray-400 mb-8">
            Contact us today for a free consultation and quote
          </p>
          <Link
            to="/contact"
            className="inline-block bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg transition-colors"
          >
            Get in Touch
          </Link>
        </div>
      </section>
    </div>
  );
}
