import { CheckCircle } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import imgQ3 from "../../imports/q3.jpeg";
import imgA3 from "../../imports/a3.jpeg";
import imgA4 from "../../imports/a4.jpeg";
import imgQ2 from "../../imports/q2.jpeg";

export function Services() {
  const services = [
    {
      title: "Bathroom Tiling",
      description:
        "Complete bathroom tiling solutions including walls, floors, and shower areas. We specialize in waterproof installations that stand the test of time.",
      image: imgQ3,
      features: [
        "Waterproof membrane installation",
        "Custom shower designs",
        "Floor heating integration",
        "Anti-slip flooring options",
      ],
    },
    {
      title: "Kitchen Backsplash",
      description:
        "Create stunning kitchen backsplashes with our expert installation. From classic subway tiles to modern patterns, we bring your vision to life.",
      image: imgA3,
      features: [
        "Custom design consultation",
        "Variety of tile patterns",
        "Precision cutting and fitting",
        "Stain-resistant grout application",
      ],
    },
    {
      title: "Floor Tiling",
      description:
        "Professional floor tiling for kitchens, bathrooms, hallways, and commercial spaces. Durable, beautiful, and expertly installed.",
      image: imgA4,
      features: [
        "Ceramic and porcelain tiles",
        "Natural stone installation",
        "Large format tiles",
        "Underfloor heating compatibility",
      ],
    },
    {
      title: "Commercial Tiling",
      description:
        "Large-scale commercial projects handled with efficiency and precision. We work with businesses to minimize downtime and maximize quality.",
      image: imgQ2,
      features: [
        "Flexible scheduling",
        "High-traffic durability",
        "Compliance with building codes",
        "Large-scale project management",
      ],
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-gray-800 to-gray-900 text-white py-20 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">Our Services</h1>
          <p className="text-xl max-w-3xl mx-auto text-gray-300">
            Professional tiling solutions tailored to your needs. From residential
            to commercial projects, we deliver excellence in every installation.
          </p>
        </div>
      </section>

      {/* Services List */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-20">
            {services.map((service, index) => (
              <div
                key={index}
                className={`flex flex-col ${
                  index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"
                } gap-12 items-center`}
              >
                <div className="lg:w-1/2">
                  <ImageWithFallback
                    src={service.image}
                    alt={service.title}
                    className="rounded-lg shadow-xl w-full h-96 object-cover"
                  />
                </div>
                <div className="lg:w-1/2">
                  <h2 className="text-3xl font-bold text-white mb-4">
                    {service.title}
                  </h2>
                  <p className="text-lg text-gray-400 mb-6">
                    {service.description}
                  </p>
                  <ul className="space-y-3">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <CheckCircle className="w-6 h-6 text-orange-500 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="bg-gray-800 py-20 border-t border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Our Process
            </h2>
            <p className="text-xl text-gray-400">
              Simple, transparent, and professional
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-orange-500 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                1
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Consultation</h3>
              <p className="text-gray-400">
                We discuss your vision and requirements
              </p>
            </div>

            <div className="text-center">
              <div className="bg-orange-500 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                2
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Quote</h3>
              <p className="text-gray-400">
                Receive a detailed, transparent estimate
              </p>
            </div>

            <div className="text-center">
              <div className="bg-orange-500 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                3
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Installation</h3>
              <p className="text-gray-400">
                Expert craftsmanship and attention to detail
              </p>
            </div>

            <div className="text-center">
              <div className="bg-orange-500 text-white rounded-full w-16 h-16 flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                4
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Completion</h3>
              <p className="text-gray-400">
                Final inspection and your satisfaction
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}